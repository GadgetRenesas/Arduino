/*
 *  $Id: _types.h,v 1.10 2013/05/02 22:24:56 nickc Exp $
 */

#ifndef _MACHINE__TYPES_H
#define _MACHINE__TYPES_H
#include <machine/_default_types.h>
#endif
